package com.develou.shoppinglist.shoppinglists;

public class ShoppingListForList {
    public String id;
    public String name;
}
