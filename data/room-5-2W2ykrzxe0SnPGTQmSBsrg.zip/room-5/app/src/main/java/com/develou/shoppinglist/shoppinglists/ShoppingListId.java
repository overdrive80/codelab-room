package com.develou.shoppinglist.shoppinglists;

public class ShoppingListId {
    public String id;

    public ShoppingListId(String id) {
        this.id = id;
    }
}
