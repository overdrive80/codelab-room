package com.develou.shoppinglist.data.partialentities;

public class ShoppingListId {
    public String id;

    public ShoppingListId(String id) {
        this.id = id;
    }
}
