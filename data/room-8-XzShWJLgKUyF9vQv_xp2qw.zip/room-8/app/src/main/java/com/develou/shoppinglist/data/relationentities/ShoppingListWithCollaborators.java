package com.develou.shoppinglist.data.relationentities;

import androidx.room.Embedded;
import androidx.room.Relation;

import com.develou.shoppinglist.data.entities.Collaborator;
import com.develou.shoppinglist.data.entities.Info;
import com.develou.shoppinglist.data.partialentities.ShoppingListForList;

import java.util.List;

public class ShoppingListWithCollaborators {
    @Embedded
    public ShoppingListForList shoppingList;

    @Relation(
            entity = Collaborator.class,
            parentColumn = "shopping_list_id",
            entityColumn = "shopping_list_id",
            projection = {"name"}
    )
    public List<String> collaboratorNames;

    @Relation(
            entity = Info.class,
            parentColumn = "shopping_list_id",
            entityColumn = "shopping_list_id",
            projection = {"created_date"}
    )
    public String createdDate;
}
